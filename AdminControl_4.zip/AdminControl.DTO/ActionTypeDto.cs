namespace AdminControl.DTO
{
    public class ActionTypeDto
    {
        public int ActionTypeID { get; set; }
        public string ActionName { get; set; } = string.Empty;
        public string ActionDescription { get; set; } = string.Empty;
    }
}
